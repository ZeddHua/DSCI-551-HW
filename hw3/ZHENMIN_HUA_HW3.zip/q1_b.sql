use sakila;

SELECT DISTINCT amount FROM payment ORDER BY amount DESC LIMIT 1 OFFSET 1;

